var j = jQuery.noConflict();
j(document).ready(function() {
	j("#logo").parent().parent().parent().show();
});