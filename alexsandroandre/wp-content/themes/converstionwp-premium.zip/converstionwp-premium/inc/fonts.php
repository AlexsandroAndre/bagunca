<?php 
    function get_fonts(){
    $fonts = array (
        '' => 'Arial',
        'raleway' => 'Raleway',
        'open-sans' => 'Open Sans',
        'roboto' => 'Roboto',
        'lato' => 'Lato',
        'pt-sans' => 'PT Sans',
        'source-sans-pro' => 'Source Sans Pro',
        'exo' => 'Exo',
        'ubuntu' => 'Ubuntu',
        'istok-web' => 'Istok Web',
        'nobile' => 'Nobile',
        'oswald' => 'Oswald',
        'montserrat' => 'Montserrat',
    );
    return $fonts;
    }
?>